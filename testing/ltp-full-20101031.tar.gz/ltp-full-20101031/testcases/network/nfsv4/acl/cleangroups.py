from random_gen import *
from optparse import OptionParser
import commands
import os
import random

test = RandomGen()
test.getGroupList()
test.cleanGroups()
