#!/bin/sh

java -cp Perfmon.jar dots.perfmon.PerfMon -port 8001
