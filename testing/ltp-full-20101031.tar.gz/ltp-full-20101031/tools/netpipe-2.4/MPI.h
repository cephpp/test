/*
  Define the protocol structure to be used by NetPIPE for MPI.
  */

typedef struct protocolstruct ProtocolStruct;
struct protocolstruct
{
	int nbor, iproc;
};

